export default function Memory() {
  return (
    <div
      style={{
        height: "100vh",
        background: "#000",
        color: "white",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "3rem",
      }}
    >
      FLOOR 1 - Childhood Memories
    </div>
  );
}
