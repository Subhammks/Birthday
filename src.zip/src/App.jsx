import { Routes, Route } from "react-router-dom";

import Portal from "./pages/Portal";
import Elevator from "./pages/Elevator";
import Memory from "./pages/Memory";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Portal />} />
      <Route path="/elevator" element={<Elevator />} />
      <Route path="/memory" element={<Memory />} />
    </Routes>
  );
}

export default App;
