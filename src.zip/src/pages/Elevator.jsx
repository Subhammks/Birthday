import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Elevator() {
  const [floor, setFloor] = useState("P");
  const [openDoor, setOpenDoor] = useState(false);
  const [showGift, setShowGift] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const floors = ["1", "2", "3", "4"];

    floors.forEach((f, index) => {
      setTimeout(
        () => {
          setFloor(f);
        },
        (index + 1) * 1200,
      );
    });

    setTimeout(() => {
      setOpenDoor(true);
    }, 5000);

    setTimeout(() => {
      setShowGift(true);
    }, 5500);
  }, []);

  return (
    <>
      <div className="elevator">
        <div className="building">BUILDING 101</div>

        <div className="quarantine">QUARANTINE BLOCK</div>

        <div className="display">FLOOR {floor}</div>

        <div className="doorFrame">
          <div className={`door leftDoor ${openDoor ? "openLeft" : ""}`}></div>

          <div
            className={`door rightDoor ${openDoor ? "openRight" : ""}`}
          ></div>

          <div className="insideLight"></div>

          {showGift && (
            <div className="giftPreview" onClick={() => navigate("/floor1")}>
              🎁
              <div className="giftText">RESIDENT GIFT DETECTED</div>
            </div>
          )}
        </div>

        <div className="panel">
          <button>P</button>

          <button className={floor === "1" ? "active" : ""}>1</button>

          <button className={floor === "2" ? "active" : ""}>2</button>

          <button className={floor === "3" ? "active" : ""}>3</button>

          <button className={floor === "4" ? "active" : ""}>4</button>
        </div>
      </div>

      <style>{`
        .elevator{
          height:100vh;

          background:
          radial-gradient(
            circle at center,
            #131f30,
            #020202
          );

          display:flex;
          flex-direction:column;
          justify-content:center;
          align-items:center;

          color:white;

          perspective:2000px;

          overflow:hidden;
        }

        .building{
          color:#ff4444;

          font-weight:700;

          letter-spacing:8px;

          margin-bottom:10px;

          text-shadow:
          0 0 15px red;
        }

        .quarantine{
          letter-spacing:5px;

          opacity:.7;

          margin-bottom:30px;
        }

        .display{
          width:260px;
          height:90px;

          margin-bottom:30px;

          background:#000;

          color:#ff4444;

          font-size:2.5rem;
          font-weight:700;

          display:flex;
          justify-content:center;
          align-items:center;

          border-radius:10px;

          box-shadow:
          0 0 20px red,
          inset 0 0 20px red;
        }

        .doorFrame{
          width:420px;
          height:600px;

          position:relative;

          overflow:hidden;

          transform:
          rotateX(8deg)
          rotateY(-8deg);

          box-shadow:
          0 40px 80px rgba(0,0,0,.7);
        }

        .insideLight{
          position:absolute;
          inset:0;

          background:
          radial-gradient(
            circle,
            rgba(120,180,255,.3),
            transparent 70%
          );
        }

        .door{
          position:absolute;
          top:0;

          width:50%;
          height:100%;

          background:
          linear-gradient(
            to right,
            #4b5563,
            #1f2937
          );

          border:1px solid #777;

          transition:2s ease;

          z-index:5;
        }

        .leftDoor{
          left:0;
        }

        .rightDoor{
          right:0;
        }

        .openLeft{
          transform:translateX(-100%);
        }

        .openRight{
          transform:translateX(100%);
        }

        .giftPreview{
          position:absolute;

          inset:0;

          display:flex;
          flex-direction:column;
          justify-content:center;
          align-items:center;

          z-index:4;

          cursor:pointer;

          animation:
          giftAppear 1.5s ease,
          floatGift 3s ease-in-out infinite;
        }

        .giftPreview::before{
          content:"";

          position:absolute;

          width:250px;
          height:250px;

          border-radius:50%;

          background:
          radial-gradient(
            circle,
            rgba(120,180,255,.25),
            transparent
          );

          filter:blur(40px);
        }

        .giftPreview{
          font-size:120px;
        }

        .giftText{
          margin-top:20px;

          color:#cfe6ff;

          letter-spacing:4px;

          font-size:.9rem;

          text-shadow:
          0 0 10px rgba(120,180,255,.8);
        }

        @keyframes giftAppear{
          from{
            opacity:0;
            transform:
            translateY(80px)
            scale(.5);
          }

          to{
            opacity:1;
            transform:
            translateY(0)
            scale(1);
          }
        }

        @keyframes floatGift{
          0%{
            transform:translateY(0px);
          }

          50%{
            transform:translateY(-15px);
          }

          100%{
            transform:translateY(0px);
          }
        }

        .panel{
          margin-top:40px;

          display:grid;
          grid-template-columns:
          repeat(2,80px);

          gap:15px;
        }

        .panel button{
          width:80px;
          height:80px;

          border:none;

          border-radius:50%;

          background:
          linear-gradient(
            #666,
            #222
          );

          color:white;

          font-size:1.3rem;

          box-shadow:
          0 8px 20px rgba(0,0,0,.6);

          cursor:pointer;
        }

        .active{
          background:#ff4444 !important;

          box-shadow:
          0 0 20px red,
          0 0 40px red,
          0 0 80px red;
        }

        @media(max-width:768px){

          .doorFrame{
            width:300px;
            height:450px;
          }

          .display{
            width:220px;
            font-size:2rem;
          }

          .giftPreview{
            font-size:90px;
          }
        }
      `}</style>
    </>
  );
}
